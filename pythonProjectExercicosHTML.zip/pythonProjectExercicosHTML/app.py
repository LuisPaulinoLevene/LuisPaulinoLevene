from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import mysql.connector

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Configuração da conexão MySQL
db = mysql.connector.connect(
    host="localhost",
    port=33061,
    user="root",
    password="123456",
    database="maquina"
)
cursor = db.cursor(dictionary=True)

# Modelo Pydantic para os dados do formulário
class DadosFormulario(BaseModel):
    nome: str
    idade: int
    bi: str

@app.get("/")
async def exibir_formulario(request: Request):
    # Renderize o template menu.html junto com o formulário
    return templates.TemplateResponse("formulario.html", {"request": request})

@app.post("/enviar_dados")
async def enviar_dados(request: Request, dados: DadosFormulario):
    nome = dados.nome
    idade = dados.idade
    bi = dados.bi

    inserir_dados = "INSERT INTO usuario (nome, idade, bi) VALUES (%s, %s, %s)"
    valores = (nome, idade, bi)

    cursor.execute(inserir_dados, valores)
    db.commit()

    # Após o envio dos dados, redirecione de volta para o formulário
    return {"message": "Dados inseridos com sucesso!"}

@app.get("/listar_usuarios")
async def listar_usuarios(request: Request):
    cursor.execute("SELECT * FROM usuario")
    usuarios = cursor.fetchall()

    # Renderize o template menu.html junto com a lista de usuários
    return templates.TemplateResponse("listar_usuarios.html", {"request": request, "usuarios": usuarios})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)