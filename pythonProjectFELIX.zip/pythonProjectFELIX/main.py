from fastapi import FastAPI, Request, Form, HTTPException, Path
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse, JSONResponse
import mysql.connector
import uuid
from pydantic import BaseModel
import re
from datetime import datetime, date



app = FastAPI()
templates = Jinja2Templates(directory="templates")

# Variável global para controlar a autenticação do administrador
is_admin_authenticated = False

# Dicionário para mapear UUIDs aos usuários autenticados
uuid_to_user = {}

# Configuração da conexão com o banco de dados MySQL
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "123456",
    "database": "felix",
    "port": 33061,
}

conn = mysql.connector.connect(**db_config)
cursor = conn.cursor()

# Expressão regular para validar UUID
uuid_regex = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


# Rota para a página de login
@app.get("/")
async def login(request: Request):
    return templates.TemplateResponse("admin.html", {"request": request})


# Rota para processar o login (aceita dados de formulário)
@app.post("/admin/")
async def process_login(username: str = Form(...), password: str = Form(...)):
    global is_admin_authenticated  # Usar a variável global


    # Consulte o banco de dados para verificar as credenciais
    cursor.execute("SELECT username, password FROM administradores WHERE username = %s", (username,))
    user_data = cursor.fetchone()

    if user_data and user_data[1] == password:
        # Autenticação bem-sucedida, definir a variável global como verdadeira
        is_admin_authenticated = True
        # Gerar um UUID aleatório
        uuid_str = str(uuid.uuid4())
        # Mapear o UUID ao usuário autenticado
        uuid_to_user[uuid_str] = username
        # Redirecionar para a página de clientes com o UUID na URL
        return RedirectResponse(f"/{uuid_str}")
    else:
        # Autenticação falhou, exibir mensagem de erro
        raise HTTPException(status_code=401, detail="Credenciais inválidas")




# Rota para lidar com solicitações POST na rota /{uuid}
@app.post("/{uuid}")
async def post_clientes_page(request: Request, uuid: str = Path(...)):
    global is_admin_authenticated  # Usar a variável global

    # Verificar se o usuário está autenticado como administrador
    if not is_admin_authenticated:
        # Redirecionar de volta para a página de login
        return RedirectResponse("/", status_code=302)

    # Verificar se o UUID está no formato correto usando a expressão regular
    if not uuid_regex.match(uuid):
        # Redirecionar de volta para a página de login com erro
        return RedirectResponse("/", status_code=302)

    # Verificar se o UUID está mapeado a um usuário autenticado
    username = uuid_to_user.get(uuid)
    if username:
        # Aqui você pode adicionar a lógica para lidar com as solicitações POST
        # Por exemplo, processar o formulário de clientes
        # ...
        return templates.TemplateResponse("menu.html", {"request": request, "username": username})
    else:
        # Se o UUID não estiver mapeado a um usuário, redirecionar para a página de clientes
        return templates.TemplateResponse("admin.html", {"request": request})

@app.get("/admin")
async def admin_page(request: Request):
    return templates.TemplateResponse("admin.html", {"request": request})


# Rota para a página de empréstimo com UUID gerado automaticamente na URL
@app.get("/emprestimo")
async def emprestimo_page(request: Request):
    # Gere um UUID aleatório
    uuid_str = str(uuid.uuid4())
    # Redirecione o usuário para a rota com o UUID na URL
    return RedirectResponse(url=f"/emprestimo/{uuid_str}")

# Rota para a página de empréstimo com UUID na URL
@app.get("/emprestimo/{uuid}")  # Use "/emprestimo/{uuid}"
async def emprestimo_page_with_uuid(request: Request, uuid: str):
    return templates.TemplateResponse("emprestimo.html", {"request": request, "uuid": uuid})



# Rota para processar o envio do formulário de empréstimo
@app.post("/emprestimo/{uuid}")
async def processar_emprestimo(
    request: Request,
    uuid: str,
    nome: str = Form(...),
    bi: str = Form(...),
    celular: str = Form(...),
    valor_emprestimo: float = Form(...),
    valor_divida: float = Form(...),
    taxa_juro_mensal: float = Form(...),
    data_emprestimo: str = Form(...),
    ultima_data_pagamento: str = Form(...),
):
    try:
        # Conectar ao banco de dados (substitua com suas configurações)
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Inserir os dados na tabela "usuarios"
        sql = """
            INSERT INTO usuarios (nome, bi, celular, valor_emprestimo, valor_divida, taxa_juro_mensal, data_emprestimo, ultima_data_pagamento)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            nome,
            bi,
            celular,
            valor_emprestimo,
            valor_divida,
            taxa_juro_mensal,
            data_emprestimo,
            ultima_data_pagamento
        )
        cursor.execute(sql, values)
        conn.commit()

        # Feche a conexão com o banco de dados
        cursor.close()
        conn.close()

        # Exibir uma mensagem de sucesso
        mensagem = "Dados inseridos com sucesso!"
        # Redirecionar o usuário para a página "admin.html" após o envio bem-sucedido
        return RedirectResponse("/admin?mensagem=" + mensagem, status_code=303)

    except Exception as e:
        # Em caso de erro, exibir uma mensagem de erro
        mensagem = f"Erro ao inserir os dados: {str(e)}"
        # Redirecionar o usuário para a página "admin.html" com a mensagem de erro
        return RedirectResponse("/admin?mensagem=" + mensagem, status_code=303)

def converter_data(data_emprestimo: str, ultima_data_pagamento: str):
    # Define o formato de entrada das datas (dd/mm/yyyy)
    formato_entrada = "%d/%m/%Y"

    try:
        # Converte as datas para o formato interno (yyyy/mm/dd)
        data_emprestimo = datetime.strptime(data_emprestimo, formato_entrada).strftime("%Y-%m-%d")
        ultima_data_pagamento = datetime.strptime(ultima_data_pagamento, formato_entrada).strftime("%Y-%m-%d")
        return data_emprestimo, ultima_data_pagamento
    except ValueError:
        # Se a conversão falhar, retorna None para indicar erro
        return None, None

# Rota para a página de pagamento com UUID gerado automaticamente na URL
@app.get("/pagamento")
async def pagamento_page(request: Request):
    # Gere um UUID aleatório
    uuid_str = str(uuid.uuid4())
    # Redirecione o usuário para a rota com o UUID na URL
    return RedirectResponse(url=f"/pagamento/{uuid_str}")

# Rota para a página de pagamento com UUID na URL
@app.get("/pagamento/{uuid}")  # Use "/pagamento/{uuid}"
async def pagamento_page_with_uuid(request: Request, uuid: str):
    return templates.TemplateResponse("pagamento.html", {"request": request, "uuid": uuid})

# Função para formatar datas no formato yyyy/mm/dd
def format_date(date_str):
    try:
        parts = date_str.split('/')
        if len(parts) == 3:
            return f"{parts[2]}/{parts[1]}/{parts[0]}"
    except:
        pass
    return None


# Rota para listar usuários em uma tabela HTML
@app.get("/lista")
async def listar_usuarios_html(request: Request):
    try:
        cursor.execute("SELECT * FROM usuarios")
        usuarios = cursor.fetchall()

        # Formatar datas no formato yyyy/mm/dd usando a função format_date
        usuarios_formatados = []
        for usuario in usuarios:
            usuario_formatado = {
                "id": usuario[0],
                "nome": usuario[1],
                "bi": usuario[2],
                "celular": usuario[3],
                "valor_emprestimo": usuario[4],
                "valor_divida": usuario[5],
                "taxa_juro_mensal": usuario[6],
                "data_emprestimo": formatar_data(f"{usuario[7]}"),
                "ultima_data_pagamento": formatar_data(f"{usuario[8]}")
            }
            usuarios_formatados.append(usuario_formatado)


        return templates.TemplateResponse("lista_usuarios.html", {"request": request, "usuarios": usuarios_formatados})
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

# Função para converter a data de "yyyy/mm/dd" para "dd/mm/yyyy"
def formatar_data(data):
    return '-'.join(data.split('-')[::-1])

# Função para converter datas nas colunas "Data do Empréstimo" e "Última Data de Pagamento"
def converter_datas(rows):
    for row in rows:
        row['data_emprestimo'] = formatar_data(row['data_emprestimo'])
        row['ultima_data_pagamento'] = formatar_data(row['ultima_data_pagamento'])



# Rota para listar usuários em uma tabela HTML
@app.get("/lista_usuarios")
async def listar_usuarios_html(request: Request):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM usuarios")
        usuarios = cursor.fetchall()

        # Converter as datas nas colunas "Data do Empréstimo" e "Última Data de Pagamento"
        converter_datas(usuarios)

        cursor.close()
        conn.close()


        return templates.TemplateResponse("lista_usuarios.html", {"request": request, "usuarios": usuarios})
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)


# Rota para acessar a página de exclusão de usuário (alterando para aceitar GET)
@app.get("/apagar")
async def apagar_usuario_page(request: Request):
    return templates.TemplateResponse("apagar_usuario.html", {"request": request})

# Rota para lidar com a exclusão de usuário (POST)
@app.post("/apagar-usuario")
async def apagar_usuario(request: Request, user_id: int = Form(...)):
    try:
        # Verificar se o usuário com o ID fornecido existe
        cursor.execute("SELECT * FROM usuarios WHERE id=%s", (user_id,))
        usuario = cursor.fetchone()

        if usuario:
            # Se o usuário existe, execute a exclusão
            cursor.execute("DELETE FROM usuarios WHERE id=%s", (user_id,))
            conn.commit()
            mensagem = f"Usuário com ID {user_id} apagado com sucesso."
            return RedirectResponse("/exclusao-confirmada?mensagem=" + mensagem, status_code=303)
        else:
            # Se o usuário não existe, retorne uma mensagem de erro
            mensagem = f"Usuário com ID {user_id} não encontrado."
            return RedirectResponse("/erro-na-exclusao?mensagem=" + mensagem, status_code=303)

    except Exception as e:
        # Em caso de erro, retorne uma mensagem de erro
        mensagem = f"Erro ao apagar usuário: {str(e)}"
        return RedirectResponse("/erro-na-exclusao?mensagem=" + mensagem, status_code=303)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
